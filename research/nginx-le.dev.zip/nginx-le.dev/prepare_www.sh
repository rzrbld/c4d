#!/bin/bash

echo "copy mxgraph-demo -------------"
nvm unload &
mkdir etc/data/mxgraph-demo
cp -r ../mxgraph-demo etc/data/ && \
echo "remove dev deps ---------------"
cd etc/data/mxgraph-demo && export NODE_ENV="production" && \
echo "rename node_modules to libs ---"
pwd &&
mv node_modules src/libs
echo "copy config files -------------"
cp ../../../../mxgraph-demo/mxgraph.config.js src/mxgraph.config.js
cp ../../../../mxgraph-demo/c4ke.config.dev.js src/c4ke.config.js
cp ../../../../mxgraph-demo/c4ke.view.config.js src/c4ke.view.config.js
echo "DONE --------------------------"